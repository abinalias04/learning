#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
#include <ctype.h>
char str[100];
char name1[100];
int validname(AddressBook *addressBook,int );
//int validmobilenumber(AddressBook *, int,char *);
//int validemailid(AddressBook *, int);




int validemailid(AddressBook *addressBook, int i, const char *email)
{
    // Check if the email contains '@' and a valid domain (like .com)
    if (strchr(email, '@') == NULL || strstr(email, ".com") == NULL)
    {
        printf("Enter a valid email address.\n");
        return 0;  // Invalid email
    }

    // Additional checks for the position of '@' and '.'
    const char *at = strchr(email, '@');
    if (at == email || at == NULL || at[1] == '\0' || strchr(at, '.') == NULL)
    {
        printf("Invalid email address. Ensure it's formatted correctly.\n");
        return 0;
    }

    // Check for duplicate email ID in the address book
    for (int j = 0; j < addressBook->contactCount; j++)
    {
        if (j != i && strcmp(addressBook->contacts[j].email, email) == 0)
        {
            printf("Invalid email. This email address is already in use.\n");
            return 0;  // Duplicate email found
        }
    }

    return 1;  // Email is valid
}

int validmobilenumber(AddressBook *addressBook, int i,char* fun,char* num)
{
    

    //= addressBook->contacts[i].phone;.
    for (int j = 0; num[j] != '\0'; j++)
    {
        if (!isdigit(num[j]))
        {
            printf("Invalid phone number. Please enter only digits.\n");

            return 0;
        }
    }

    // Check for exact 10 digits
    if (strlen(num) != 10)
    {
        printf("Invalid phone number. Please minimum 10 digits.\n");

        return 0;
    }

    // Check for duplicate phone number
    if(strcmp(fun,"create") == 0)
    {
    for (int j = 0; j < addressBook->contactCount; j++)
    {
        if (j != i && strcmp(addressBook->contacts[j].phone, num) == 0)
        {
            printf("Invalid phone number.Phone numbetr is already in this.\n");
            return 0;
        }
    }
    }
    return 1;
}
int mobilenumbervalid(char *str)
{
    
    int flag = 0;
    for (int j = 0; str[j] != '\0'; j++)
    {
        if (!isdigit(str[j]))
        {
            flag = 1;
        }
    }

    // Check for exact 10 digits 
    if (strlen(str) != 10)
    {
        printf("Enter a valid 10-digit mobile number:\n");
        flag = 1;
    }
    if (flag == 0)
    {
        return 1;
    }
    else
        return 0;
}
int validname(AddressBook *addressBook, int i)
{
    int valid = 0;
   
    while (!valid)
    {
       
        printf("Enter the name: ");
        scanf(" %[^\n]", name1);  // Read the entire line, including spaces
        getchar();  // Clear the newline character from the buffer

        valid = 1;  // Assume input is valid initially

        for (int j = 0; name1[j] != '\0'; j++)
        {
            if (!isalpha(name1[j]) && name1[j] != ' ')
            {
                printf("Invalid Name. Please enter only alphabets and spaces.\n");
                valid = 0;
                break;
            }
        }
    }
    return 1;   

   // printf("valid name is entered..\n");
}

void listContacts(AddressBook *addressBook) 
{
    if(addressBook->contactCount == 0)
    {
        printf("No contacts available\n");
        return;
    }
    // for(int i=0; i<addressBook->contactCount-1;i++)
    // {
    //     for(int j=i+1; j<addressBook->contactCount;j++)
    //     {
    //         // if(strcmp(addressBook->contacts[i].name,addressBook->contacts[j].name)>0)
    //         // {
    //         //     Contact temp =addressBook->contacts[i];
    //         //     addressBook->contacts[i]=addressBook->contacts[j];
    //         //     addressBook->contacts[j] = temp;

    //         // }
    //     }
    // }
    printf("CONTACT\t\tNAME\t\tMb_number\t\tEmail\t\n");
    printf("-----------------------------------------------------------------------");
    for(int i=0; i < addressBook->contactCount;i++)
    {
        //printf("Contact %d: \n",i+1);
        printf("\n");
        printf(" %-10d %-20s %-20s %-20s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    
}

void initialize(AddressBook *addressBook)
 {
   addressBook->contactCount = 0;
   
    // Load contacts from file during initialization (After files)
  
}

void saveAndExit(AddressBook *addressBook)
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

void createContact(AddressBook *addressBook)
{

    if (addressBook->contactCount >= MAX_CONTACTS)
    {
        printf("Address book is full. Cannot add more contacts.\n");
        return;
    }

    int i = addressBook->contactCount;

    // Get and validate name
    getchar();  // To flush newline from the buffer
    if (validname(addressBook, i))
    {
        strcpy(addressBook->contacts[i].name, name1);  // name1 is filled in validname
    }

    // Get and validate phone number
    char num[20];
    printf("Enter the mobile number: ");
    fgets(num, sizeof(num),stdin);
    num[strcspn(num, "\n")] =0;
    if (validmobilenumber(addressBook, i, "create",num))
    {
        strcpy(addressBook->contacts[i].phone, num);  // str is filled in validmobilenumber
    }

    // Get and validate email
    char email[100];
    printf("Enter the email id: ");
    fgets(email, sizeof(email), stdin);  // Capture email input
    email[strcspn(email, "\n")] = 0;  // Remove the newline character
    if (validemailid(addressBook, i,email))
    {
        strcpy(addressBook->contacts[i].email, email);  // str is filled in validemailid
    }

    // Increment contact count in memory
    addressBook->contactCount++;
    printf("New contact added successfully!\n");
}



void searchContact(AddressBook *addressBook) 
{
    int ch;
    char search[20];
    int flag=0;
    getchar();
    do 
    {
        printf("1.Enter the name \n");
        printf("2.Enter the phone No \n");
        printf("3.Enter the Email_id \n");
        printf("4.Exit \n");
        printf("Enter your choice ");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:
                printf("Enter the name of the person you want to search: ");
                scanf(" %[^\n]",search);
                for(int i=0; i<addressBook->contactCount; i++)
                {
                    if(strcmp(addressBook->contacts[i].name,search)==0)
                    {
                        flag = 1;
                        printf("\nName: %s\n\nPhone: %s\n\nEmail: %s\n\n", 
                    addressBook->contacts[i].name, 
                    addressBook->contacts[i].phone, 
                    addressBook->contacts[i].email);
                    
                    }
                }
                break; 
            case 2:
                printf("Enter the phone no of the person you want to search: ");
                scanf(" %[^\n]",search);
                for(int i=0; i<addressBook->contactCount; i++)
                {
                    if(strcmp(addressBook->contacts[i].phone,search)==0)
                    {
                        flag = 1;
                        printf("\nName: %s\n\nPhone: %s\n\nEmail: %s\n\n", 
                    addressBook->contacts[i].name, 
                    addressBook->contacts[i].phone, 
                    addressBook->contacts[i].email);
                    
                    }
                }
                break; 
            case 3:
                printf("Enter the Email_id of the person you want to search: ");
                scanf(" %[^\n]",search);
                for(int i=0; i<addressBook->contactCount; i++)
                {
                    if(strcmp(addressBook->contacts[i].email,search)==0)
                    {
                        flag = 1;
                        printf("\nName: %s\n\nPhone: %s\n\nEmail: %s\n\n", 
                    addressBook->contacts[i].name, 
                    addressBook->contacts[i].phone, 
                    addressBook->contacts[i].email);
                    }    
                }
                break;
                default:
                return;
    
        }

    }
    while(ch!=4);
    
}

void editContact(AddressBook *addressBook)
{
    char detail[30];  
    int flag = 0; 
    int i;  
    getchar();  
    printf("Enter the name of the person to edit: \n");
    scanf("%[^\n]", detail);  
    getchar();  

    // Search for the contact by name 
    for (i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].name,detail) == 0)
        {
            flag = 1;
            break;  
        }
    }

    // If contact not found, print an error and return
    if (flag == 0)
    {
        printf("Person not found in the list.\n");
        return;
    }

    // Now proceed with editing options
    int opt;
    char name1[100];  
    char str[100];   
    char num[20]; 

    while (1)
    {
        
        printf("\n1. Edit name\n2. Edit phone number\n3. Edit email ID\n4. Save\n5. Exit\n");
        printf("Choose an option: ");
        scanf("%d", &opt);

        switch (opt)
        {
            case 1:  
                printf("Enter new name: ");
                getchar();
                fgets(name1, sizeof(name1), stdin);
                name1[strcspn(name1, "\n")] = 0; 
                if (validname(addressBook, i))
                {
                    strcpy(addressBook->contacts[i].name, name1);
                }
                break;

            case 2:  
                printf("Enter new phone number: ");
                getchar();
                fgets(num, sizeof(num), stdin);
                num[strcspn(num, "\n")] = 0;
                if (validmobilenumber(addressBook, i, "edit",num))
                {
                    strcpy(addressBook->contacts[i].phone, num);
                }
                break;

            case 3:  
                printf("Enter new email ID: ");
                getchar();
                 fgets(str, sizeof(str), stdin);
                str[strcspn(str, "\n")] = 0;
                {
                    strcpy(addressBook->contacts[i].email, str);
                }
                break;

            case 4:  
                printf("Changes saved successfully!\n");
                return;

            case 5:  
                printf("Exiting without saving.\n");
                return;

            default:
                printf("Invalid entry. Please choose a valid option.\n");
        }
    }
}


void deleteContact(AddressBook *addressBook)
{
    char name2[30];
    int flag = 0;

    getchar();  // To flush the newline character
    printf("Enter the name of the person to be deleted: ");
    scanf("%[^\n]", name2);
    getchar();  // Flush the newline again

    // Search for the contact by phone number
    for (size_t i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].name, name2) == 0)
        {
            flag = 1;
            // Shift contacts after the deleted one
            for (int j = i; j < addressBook->contactCount - 1; j++)
            {
                addressBook->contacts[j] = addressBook->contacts[j + 1];
            }

            // Clear the last contact (since it's shifted)
            addressBook->contacts[addressBook->contactCount - 1].name[0] = '\0';
            addressBook->contacts[addressBook->contactCount - 1].phone[0] = '\0';
            addressBook->contacts[addressBook->contactCount - 1].email[0] = '\0';

            // Decrease contact count
            addressBook->contactCount--;
            printf("Contact deleted successfully!\n");
            break;
        }
    }

    if (!flag)
    {
        printf("Person not found in the list.\n");
    }
}
