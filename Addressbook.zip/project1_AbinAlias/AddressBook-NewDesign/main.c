#include <stdio.h>
#include "contact.h"
#include <unistd.h>
#include"file.h"
void displayLoading(int duration) {
    int progress = 0;
    int barWidth = 100;  // Width of the loading bar

    printf("Saving.....\n");

    while (progress <= 100) {
        int position = (progress * barWidth) / 100;
        printf("[");
        for (int i = 0; i < barWidth; i++) {
            if (i < position)
                printf("=");
            else if (i == position)
                printf(">");
            else
                printf(" ");
        }
        printf("] %d%%\r", progress);
        fflush(stdout);  // Force print to screen without newline

        usleep(duration * 10000);  // Sleep for 'duration' milliseconds
        progress++;
    }

    printf("\nSaving complete!\n");
}

int main() {
    int duration = 2;
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book
    loadContactsFromFile(&addressBook);

    do {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
        printf("6. Exit\n");
        printf(" Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:
                listContacts(&addressBook);
                break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);
                displayLoading(duration);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);
    
       return 0;
}
